import sys
import xml.sax
import Tkinter as tk
import include.controller

if __name__ == "__main__":
  controller = include.controller.Controller()
  tk.mainloop()
